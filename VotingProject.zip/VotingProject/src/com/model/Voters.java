package com.model;

public class Voters {
	 public int vid;
	    public String vPreference;

	    public int getVid() {
	        return vid;
	    }

	    public void setVid(int vid) {
	        this.vid = vid;
	    }

	    public String getvPreference() {
	        return vPreference;
	    }

	    public void setvPreference(String vPreference) {
	        this.vPreference = vPreference;
	    }
}
